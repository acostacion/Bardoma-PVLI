import Slime from "./slime.js";

export default class Slime2 extends Slime {
    constructor(scene, x, y){
        super(scene, x, y);
    }

    //Sobrescribimos el método setDirection de Slime, el padre.
    setDirection(){
        this.dir = -1;
    }
}