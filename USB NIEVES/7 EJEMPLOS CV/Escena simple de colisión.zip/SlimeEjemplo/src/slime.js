export default class Slime extends Phaser.GameObjects.Sprite {
    constructor(scene, x, y) {
        super(scene, x, y, "slime", 8);

        this.scene.add.existing(this);
        this.scene.physics.add.existing(this); //Añadimos físicas

        this.body.setAllowGravity(false); //Quitamos gravedad
        this.body.setSize(16, 16);

        this.setScale(5, 5)
        this.play("jump_slime"); //ejecutamos animación

        this.body.setBounce(0.2);

        this.setDirection();

        this.life = 3;
        console.log("Mi vida", this.life)
    }

    loseLife() {
        this.life -= 1;
        console.log("Mi vida", this.life)
    }
    move() {
        this.body.setVelocityX(100 * this.dir)
    }

    setDirection() {
        this.dir = 1
    }

    preUpdate(t, dt) {
        super.preUpdate(t, dt); //recorad siempre el super del preUpdate en los Sprites
    }
}