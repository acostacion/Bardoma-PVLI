import Slime from "./slime.js";
import Slime2 from "./slime2.js";

export default class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: "game" })
    }

    init() {

    }

    preload() {

    }

    create() {
        this.bg = this.add.image(0, 0, "castle").setOrigin(0, 0);

        this.text = this.add.text(200, 200, "Jugar",
            { fontFamily: 'comicate', fontSize: 2, color: '#FFFF00' }
        );



        let sl = new Slime(this, 0, 200);
        let sl2 = new Slime2(this, 500, 200);

        let dkey = this.input.keyboard.addKey("D");

        dkey.on("down", () => {
            sl.move();
            sl2.move()
            console.log("pulsadaD")
        })

        this.physics.add.collider(sl, sl2, (o1, o2) => {  //la función callback recibirá los dos objetos de Phaser que colisionan, util cuando tenemos listas de objetos que pueden colisionar ya que nos dirá el objeto específico
            console.log("Los limos han colisionado");
            sl.loseLife();
        })

        /*
        //Con este codigo se puede probar overlap
        this.physics.add.overlap(sl, sl2, () => {
            console.log("Los limos han hecho overlap");
            sl.loseLife();
        })*/

        this.cameras.main.startFollow(sl)


        //this.text.setScrollFactor(1,1); ///cambiar camara sobre la que se hace el scrollFactor.
    }

    update(t, dt) {

    }
}