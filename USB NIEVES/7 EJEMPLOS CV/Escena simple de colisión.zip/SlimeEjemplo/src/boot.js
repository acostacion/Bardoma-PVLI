/**
 * Base de una escena de carga
 */
export default class Boot extends Phaser.Scene {
    constructor(){
        super({key:"boot"})
    }

    init(){

    }

    preload(){
        // carga de recursos
        this.load.image("castle", "../assets/castle.gif")
        this.load.image("start", "../assets/start.png")
        this.load.spritesheet("slime", "../assets/greenSlime.png", {frameWidth: 48, frameHeight: 48} )
        
        // eventos de carga que nos interesan
        this.load.on('progress', function (value) {
            console.log("progressEvent", value);
        });      
        this.load.on('fileprogress', function (file) {
            console.log("fileprogressEvent", file.src);
        });
        this.load.on('complete', function (f) {
            console.log("filecompleteEvent", 'complete');
            // https://newdocs.phaser.io/docs/3.86.0/Phaser.Types.Time.TimerEventConfig
            this.scene.scene.start("game") //this.scene.scene porque en este método preload no estamos en la escena, this será Phaser.
            /*
            //Timer para lanzar la escena después de 2 segundos
            this.scene.time.addEvent({
                delay: 2000,
                callback: ()=> {this.scene.scene.start("title")}
            })*/
        });
    }

    create(){
        //Texto con la fuente "comicate" que ya está cargada en el css de la web
        this.text = this.add.text(50,20, ".", { 
            fontFamily: 'comicate', 
            fontSize: 80, 
            color: '#FFFF00'}
        )
        this.count = 0;

        //Creación de la animación del limo
        this.anims.create({
			key: 'jump_slime',
			frames: this.anims.generateFrameNumbers('slime', {start:30, end:32}),
			frameRate: 5,
			repeat: -1,
            yoyo: -1
		});
    }

    // pintar puntos suspensivos para representar la carga, esto podríamos hacerlo según los eventos escuchados del preload.
    update(t, dt){
        this.count += dt;
        if(this.count > 500){
            this.count = 0;
            this.text.setText(this.text.text+".");
        }
    }
}