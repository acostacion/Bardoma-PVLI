# Ejemplo de "juego" con Phaser 3
## Asignatura PVLI - UCM

El ejemplo consiste en 3 escenas:
 - Título
 - Escena principal
 - Game Over
 
El juego comienza si se pulsa con el ratón sobre el botón "Start" de la escena de Título.
Durante el juego el jugador puede saltar (W), moverse (A, S) y atacar (Space). 
Se pueden romper las cajas al golpearlas, cada vez que se destruye una caja aparecerá una nueva.

Si se destruyen 5 cajas o pasan 30s el juego se detiene y aparece la escena de GameOver, al pulsar sobre ésta, se vuelve a las escena de título.
